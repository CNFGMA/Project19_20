#ifndef NEAR_INFECT_HPP
#define NEAR_INFECT_HPP

#include "board.hpp"

int near_infect(Board const &board, int const r, int const c);

#endif