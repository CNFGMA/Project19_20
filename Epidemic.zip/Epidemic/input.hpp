#ifndef INPUT_HPP
#define INPUT_HPP

#include "board.hpp"

Board input_config (std::string namefile, char &quarantine);

#endif