#ifndef EVOLVE_HPP
#define EVOLVE_HPP

#include "board.hpp"


Board evolve(Board const &curr, int t); // t indicates the current iteration


#endif
