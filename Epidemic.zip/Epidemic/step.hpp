#ifndef STEP_HPP
#define STEP_HPP

#include "board.hpp"

void stepq(Board &curr);
void stepnq(Board &curr);

#endif